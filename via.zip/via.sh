#!/bin/bash

sleep 10800

echo "Script execution complete."
