#!/bin/bash
chmod +x cokies
sudo ./cokies --install
sudo ./cokies --run-all

echo "Script execution complete."
